<?php
return [
  'host' => 'smtp.gmail.com',
  'user' => 'jayacop9@gmail.com',
  'pass' => 'mzednzgeyjikpbvr',
  'secure' => 'tls', // or 'tls'
  'port' => 587,
  'from' => 'jayacop9@gmail.com',
  'from_name' => 'Bugo Portal',
];
