<li>
  <form method="POST" style="margin: 0;">
    <button class="dropdown-item logout-btn" type="submit" name="logout" value="true">Logout</button>
  </form>
</li>
